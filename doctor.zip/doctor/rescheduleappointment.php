<!DOCTYPE html>
<html>
<head>
</head>
<body>
	
<form action="reschedulec.php" method="post" />
<p>Enter appointment ID of appointment to reschedule</p>
<p>Appointment ID: <input type="text" name="app_id" /></p>

<p>Enter new date and time</p>
<p>Appointment date and time : <input type="datetime-local" name="appdateTime" placeholder="0000-00-00 00:00:00" /></p>

 <input type="submit" value="Submit" />

</form>

</body>
</html>