<!DOCTYPE html>
<html>
<head>
</head>
<body>
	
<form action="deletec.php" method="post" />
<p>Enter appointment ID of appointment to cancel</p>
<p>Appointment ID: <input type="text" name="app_id" /></p>


 <input type="submit" value="Submit" />

</form>

</body>
</html>