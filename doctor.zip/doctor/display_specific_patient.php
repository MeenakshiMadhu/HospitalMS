<!DOCTYPE html>
<html>
<head>
</head>
<body>
	
<form action="displays.php" method="post" />
<p>Enter Your Patient's ID to display appointment details - </p>

<p>Patient ID: <input type="text" name="pu_id" /></p>

 <input type="submit" value="Submit" />

</form>

</body>
</html>