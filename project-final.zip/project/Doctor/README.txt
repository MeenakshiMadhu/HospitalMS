Cancelappointment and deletec.php are for cancellation
reschedule and updatec for rescheduling

--------------IMP-----------

displayspecificpatient.php and displays.php ---> for displaying specific patients under the doctor 

displayrandompatient.php and displayr.php ----> for displaying random patient "not under" the doctor